package dadm.ndescot.quotationshake.utils

import java.lang.Exception

class NoInternetException:Exception()