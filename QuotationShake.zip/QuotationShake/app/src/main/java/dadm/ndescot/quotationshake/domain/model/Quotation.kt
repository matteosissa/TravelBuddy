package dadm.ndescot.quotationshake.domain.model

data class Quotation(val id: String, val quote:String, val author: String)
