package dadm.ndescot.quotationshake.ui.about

import androidx.fragment.app.DialogFragment
import dadm.ndescot.quotationshake.R
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AboutDialogFragment: DialogFragment(R.layout.fragment_about)