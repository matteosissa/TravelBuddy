package dadm.ndescot.quotationshake

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class QuotationShakeApplication: Application()